import org.apache.spark.ml.{Pipeline}
import org.apache.spark.ml.evaluation.BinaryClassificationEvaluator
import org.apache.spark.ml.feature.{HashingTF, StopWordsRemover, IDF, Tokenizer}
import org.apache.spark.sql.functions.regexp_replace
import org.apache.spark.ml.classification.{LogisticRegression => LogR}
import org.apache.spark.ml.evaluation.{MulticlassClassificationEvaluator => MCE}
import org.apache.spark.ml.linalg.{Matrix => MX, Matrices => MS}
import org.apache.spark.sql.SparkSession
import org.apache.spark.SparkContext
import org.apache.spark.SparkConf


object test extends App {

  val conf = new SparkConf().setAppName("Simple Application").setMaster("local[*]")
  val sc = new SparkContext(conf)

  val spark = SparkSession.builder
    .master("local[*]")
    .appName("Simple Application")
    .getOrCreate()

  //# Importing data
  val tweets = spark.read.option("header", "true").option("inferSchema","true").csv("C:\\Users\\muhammad\\IdeaProjects\\SparkProjects\\cleaned_650k_tweets.csv").toDF("label","text")
  tweets.show

  // Data cleaning
  val clean = tweets.withColumn("text", regexp_replace(tweets("text"), "[^A-Za-z]", " "))
  clean.show()

  // Data pre-processing
  val tweetsReview = sc.textFile("C:\\Users\\muhammad\\IdeaProjects\\SparkProjects\\cleaned_650k_tweets.csv")
  val tweetswordsReviewFlatMap = tweetsReview.filter(x => x.length > 0).flatMap(line => line.split("""\W+"""))
  val longReview = tweetswordsReviewFlatMap.filter(x => x.length >= 5)
  val longReviewPair = longReview.map(w => (w.length, 1))
  val longReviewCount = longReviewPair.reduceByKey((count1, count2) => count1 + count2)
  val greaterThanFiveMap = longReview.map(word => (word,1))
  val reduceGreaterThanFive = greaterThanFiveMap.reduceByKey((count1,count2) => count1 + count2).sortBy(-_._2)
  val reducedArray = reduceGreaterThanFive

  // Spliting data
  val Array(training, test) = clean.randomSplit(Array(0.75, 0.25), seed = 12345)

  training.count()

  test.count()


  // Preparing before passing to ML model
  val tokenizer = new Tokenizer().setInputCol("text").setOutputCol("words")
  val remover = new StopWordsRemover().setInputCol("words").setOutputCol("filtered").setCaseSensitive(false)
  val hashingTF = new HashingTF().setNumFeatures(50000).setInputCol("filtered").setOutputCol("rawFeatures")
  val idf = new IDF().setInputCol("rawFeatures").setOutputCol("features").setMinDocFreq(0)

  // Compared NB & LR - Chose LR due better Accuracy & Precision of 76%
  val lr = new LogR().setRegParam(0.01).setThreshold(0.5)


  val pipeline = new Pipeline().setStages(Array(tokenizer, remover, hashingTF, idf, lr))


  val model = pipeline.fit(training)
  val predictions = model.transform(test)
  predictions.show()

  val evaluator = new BinaryClassificationEvaluator().setMetricName("areaUnderROC")
  println("Area under the ROC curve = " + evaluator.evaluate(predictions))

  val eval = new MCE().setLabelCol("label").setPredictionCol("prediction")
  println(s"Accuracy: ${eval.setMetricName("accuracy").evaluate(predictions)}")
  println(s"Precision: ${eval.setMetricName("weightedPrecision").evaluate(predictions)}")
  println(s"Recall: ${eval.setMetricName("weightedRecall").evaluate(predictions)}")
  println(s"F1: ${eval.setMetricName("f1").evaluate(predictions)}")

  val TP = predictions.select("label", "prediction").filter("label = 0 and prediction = 0").count
  val TN = predictions.select("label", "prediction").filter("label = 1 and prediction = 1").count
  val FP = predictions.select("label", "prediction").filter("label = 0 and prediction = 1").count
  val FN = predictions.select("label", "prediction").filter("label = 1 and prediction = 0").count
  val total = predictions.select("label").count.toDouble

  val confusion: MX = MS.dense(2, 2, Array(TP, FN, FP, TN))

  // Metrics
  val accuracy = (TP + TN) / total
  val precision = (TP + FP) / total
  val recall = (TP + FN) / total
  val F1 = 2 / (1/precision + 1/recall)

}
